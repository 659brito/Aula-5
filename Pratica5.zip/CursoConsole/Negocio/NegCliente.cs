﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NegCliente
    {
        List<Cliente> ListCli = new List<Cliente>();


        public void CadastrarCliente(Cliente cliente)
        {
            ListCli.Add(cliente);
        }
        public List<Cliente> ConsultarCliente()
        {
            return ListCli;
        }
        public Cliente ConsultarClientePorNome(String nome)
        {
            foreach (var item in ListCli)
            {
                if (item.nome.Equals(nome))
                    return item;
            }
            return null;
        }

        public Cliente RemoverCliente(String nome)
        {
            foreach (var item in ListCli)
            {
                if (item.nome.Equals(nome))
                {
                    ListCli.Remove(item);
                }
            }
            return null;
        }
    }

}
