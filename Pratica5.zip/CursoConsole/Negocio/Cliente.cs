﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class Cliente : Pessoa
    {
        public long cpf { get; set; }
        public char sexo { get; set; }
        public long telefone { get; set; }
        public String endereco { get; set; }
    }
}
